"use strict";
(() => {
  // src/shared/constants.ts
  var SUPPORTED_PROVIDERS = {
    chatgpt: {
      id: "chatgpt",
      name: "ChatGPT",
      hostnamePatterns: ["chatgpt.com", "chat.openai.com"],
      homeUrl: "https://chatgpt.com",
      logo: "https://chatgpt.com/favicon.ico",
      accentColor: "#10a37f",
      capabilities: {
        canExtract: true,
        canInject: true,
        supportsStreaming: true,
        supportsAttachments: true,
        supportsConversationTitle: true
      }
    },
    claude: {
      id: "claude",
      name: "Claude",
      hostnamePatterns: ["claude.ai"],
      homeUrl: "https://claude.ai",
      logo: "https://claude.ai/favicon.ico",
      accentColor: "#d97706",
      capabilities: {
        canExtract: true,
        canInject: true,
        supportsStreaming: true,
        supportsAttachments: true,
        supportsConversationTitle: true
      }
    },
    gemini: {
      id: "gemini",
      name: "Google Gemini",
      hostnamePatterns: ["gemini.google.com"],
      homeUrl: "https://gemini.google.com",
      logo: "https://gemini.google.com/favicon.ico",
      accentColor: "#2563eb",
      capabilities: {
        canExtract: true,
        canInject: true,
        supportsStreaming: true,
        supportsAttachments: true,
        supportsConversationTitle: true
      }
    },
    perplexity: {
      id: "perplexity",
      name: "Perplexity",
      hostnamePatterns: ["perplexity.ai", "www.perplexity.ai"],
      homeUrl: "https://www.perplexity.ai",
      logo: "https://www.perplexity.ai/favicon.ico",
      accentColor: "#20b2aa",
      capabilities: {
        canExtract: true,
        canInject: true,
        supportsStreaming: true,
        supportsAttachments: false,
        supportsConversationTitle: true
      }
    },
    grok: {
      id: "grok",
      name: "Grok",
      hostnamePatterns: ["grok.com", "x.ai"],
      homeUrl: "https://grok.com",
      logo: "https://grok.com/favicon.ico",
      accentColor: "#ef4444",
      capabilities: {
        canExtract: true,
        canInject: true,
        supportsStreaming: true,
        supportsAttachments: true,
        supportsConversationTitle: true
      }
    },
    copilot: {
      id: "copilot",
      name: "Microsoft Copilot",
      hostnamePatterns: ["copilot.microsoft.com", "edgeservices.bing.com"],
      homeUrl: "https://copilot.microsoft.com",
      logo: "https://copilot.microsoft.com/favicon.ico",
      accentColor: "#0284c7",
      capabilities: {
        canExtract: true,
        canInject: true,
        supportsStreaming: true,
        supportsAttachments: false,
        supportsConversationTitle: true
      }
    },
    deepseek: {
      id: "deepseek",
      name: "DeepSeek",
      hostnamePatterns: ["chat.deepseek.com", "deepseek.com"],
      homeUrl: "https://chat.deepseek.com",
      logo: "https://chat.deepseek.com/favicon.ico",
      accentColor: "#4f46e5",
      capabilities: {
        canExtract: true,
        canInject: true,
        supportsStreaming: true,
        supportsAttachments: true,
        supportsConversationTitle: true
      }
    },
    unknown: {
      id: "unknown",
      name: "Unknown Provider",
      hostnamePatterns: [],
      homeUrl: "",
      logo: "",
      accentColor: "#6b7280",
      capabilities: {
        canExtract: false,
        canInject: false,
        supportsStreaming: false,
        supportsAttachments: false,
        supportsConversationTitle: false
      }
    }
  };

  // src/providers/base/AIProvider.ts
  var BaseAIProvider = class {
    get metadata() {
      return SUPPORTED_PROVIDERS[this.id] || SUPPORTED_PROVIDERS.unknown;
    }
    get capabilities() {
      return this.metadata.capabilities;
    }
    /**
     * Helper to dispatch input/change events to trigger React/Vue state updates on injected content.
     */
    dispatchInputEvents(element) {
      element.dispatchEvent(new Event("input", { bubbles: true }));
      element.dispatchEvent(new Event("change", { bubbles: true }));
      element.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, key: " " }));
      element.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: " " }));
    }
    /**
     * Helper to insert text into a contenteditable element preserving line breaks.
     */
    insertIntoContentEditable(element, text) {
      element.focus();
      try {
        const selection = window.getSelection();
        if (selection) {
          const range = document.createRange();
          range.selectNodeContents(element);
          selection.removeAllRanges();
          selection.addRange(range);
        }
        if (document.execCommand("insertText", false, text)) {
          this.dispatchInputEvents(element);
          return true;
        }
      } catch {
      }
      element.innerText = text;
      this.dispatchInputEvents(element);
      return true;
    }
    /**
     * Helper to insert text into standard HTMLTextAreaElement or HTMLInputElement.
     */
    insertIntoTextArea(element, text) {
      element.focus();
      element.value = text;
      this.dispatchInputEvents(element);
      return true;
    }
  };

  // src/shared/utils.ts
  function generateUniqueId(prefix = "id") {
    const rand = Math.random().toString(36).substring(2, 9);
    const timestamp = Date.now().toString(36);
    return `${prefix}_${timestamp}_${rand}`;
  }

  // src/content/dom-utils.ts
  function pasteTextIntoElement(element, text) {
    element.focus();
    try {
      const selection = window.getSelection();
      if (selection) {
        const range = document.createRange();
        range.selectNodeContents(element);
        selection.removeAllRanges();
        selection.addRange(range);
      }
      if (document.execCommand("insertText", false, text)) {
        dispatchInputEvents(element);
        return true;
      }
    } catch {
    }
    if ("value" in element) {
      try {
        const nativeSetter = Object.getOwnPropertyDescriptor(
          window.HTMLTextAreaElement.prototype,
          "value"
        )?.set;
        if (nativeSetter) {
          nativeSetter.call(element, text);
        } else {
          element.value = text;
        }
        dispatchInputEvents(element);
        return true;
      } catch {
      }
    }
    try {
      const dataTransfer = new DataTransfer();
      dataTransfer.setData("text/plain", text);
      const pasteEvent = new ClipboardEvent("paste", {
        clipboardData: dataTransfer,
        bubbles: true,
        cancelable: true
      });
      element.dispatchEvent(pasteEvent);
    } catch {
    }
    if ("value" in element) {
      element.value = text;
    } else {
      element.innerText = text;
    }
    dispatchInputEvents(element);
    return true;
  }
  function dispatchInputEvents(element) {
    element.dispatchEvent(new Event("input", { bubbles: true, cancelable: true }));
    element.dispatchEvent(new Event("change", { bubbles: true, cancelable: true }));
    element.dispatchEvent(new KeyboardEvent("keydown", { key: "a", bubbles: true }));
    element.dispatchEvent(new KeyboardEvent("keyup", { key: "a", bubbles: true }));
  }

  // src/providers/chatgpt/ChatGPTProvider.ts
  var ChatGPTProvider = class extends BaseAIProvider {
    id = "chatgpt";
    name = "ChatGPT";
    detect() {
      if (typeof window === "undefined") return false;
      const host = window.location.hostname;
      const href = window.location.href;
      if (host.includes("chatgpt.com") || host.includes("chat.openai.com") || href.includes("chatgpt.com") || href.includes("chat.openai.com")) {
        return true;
      }
      if (typeof document !== "undefined") {
        if (document.querySelector("#prompt-textarea") || document.querySelector("[data-message-author-role]")) {
          return true;
        }
      }
      return false;
    }
    async getConversationTitle() {
      if (typeof document === "undefined") return null;
      const h1 = document.querySelector("h1");
      if (h1 && h1.textContent?.trim() && !h1.textContent.includes("ChatGPT")) {
        return h1.textContent.trim();
      }
      const title = document.title;
      if (title && !title.startsWith("ChatGPT") && !title.startsWith("New chat")) {
        return title.replace(/ - ChatGPT$/, "").trim();
      }
      return "ChatGPT Conversation";
    }
    async extractConversation() {
      const messages = [];
      if (typeof document === "undefined") {
        return { id: generateUniqueId("chatgpt"), provider: this.id, messages };
      }
      let messageElements = Array.from(
        document.querySelectorAll("[data-message-author-role='user'], [data-message-author-role='assistant']")
      );
      if (messageElements.length === 0) {
        messageElements = Array.from(
          document.querySelectorAll("article, [data-message-id], [class*='conversation-turn']")
        );
      }
      const uniqueElements = Array.from(new Set(messageElements));
      for (let i = 0; i < uniqueElements.length; i++) {
        const el = uniqueElements[i];
        const role = this.getMessageRole(el, i);
        const markdownEl = el.querySelector(".markdown, .whitespace-pre-wrap, [class*='markdown']") || el;
        const content = this.cleanMessageContent(markdownEl.innerText || markdownEl.textContent || "");
        if (content) {
          messages.push({
            id: generateUniqueId(`msg_${i}`),
            role,
            content,
            timestamp: (/* @__PURE__ */ new Date()).toISOString()
          });
        }
      }
      const title = await this.getConversationTitle();
      return {
        id: generateUniqueId("chatgpt_conv"),
        title: title || "ChatGPT Conversation",
        provider: this.id,
        messages,
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
        url: typeof window !== "undefined" ? window.location.href : void 0,
        isPartial: false
      };
    }
    getMessageRole(element, index) {
      const roleValue = element.getAttribute("data-message-author-role") || element.getAttribute("data-role") || element.getAttribute("data-is-user");
      if (roleValue === "user" || roleValue === "true") return "user";
      if (roleValue === "assistant" || roleValue === "false") return "assistant";
      const descriptor = [
        element.className,
        element.getAttribute("aria-label"),
        element.getAttribute("data-testid"),
        element.parentElement?.className,
        element.parentElement?.getAttribute("data-testid")
      ].filter(Boolean).join(" ").toLowerCase();
      if (/user|human|you-message|prompt/.test(descriptor)) return "user";
      if (/assistant|bot|response|message-content/.test(descriptor)) return "assistant";
      return index % 2 === 0 ? "user" : "assistant";
    }
    cleanMessageContent(content) {
      return content.replace(/^\s*(copy|edit|retry|regenerate)\s*$/gim, "").replace(/\n{3,}/g, "\n\n").trim();
    }
    async injectContext(formattedContext) {
      if (typeof document === "undefined") return false;
      const textarea = document.querySelector("#prompt-textarea, [contenteditable='true'], textarea");
      if (textarea) {
        return pasteTextIntoElement(textarea, formattedContext);
      }
      return false;
    }
  };

  // src/providers/claude/ClaudeProvider.ts
  var ClaudeProvider = class extends BaseAIProvider {
    id = "claude";
    name = "Claude";
    detect() {
      if (typeof window === "undefined") return false;
      const host = window.location.hostname;
      const href = window.location.href;
      if (host.includes("claude.ai") || href.includes("claude.ai")) {
        return true;
      }
      if (typeof document !== "undefined") {
        if (document.querySelector(".font-claude-message") || document.querySelector('[data-testid="user-message"]')) {
          return true;
        }
      }
      return false;
    }
    async getConversationTitle() {
      if (typeof document === "undefined") return null;
      const titleBtn = document.querySelector("button[data-testid='chat-title-button'], [aria-label*='rename']");
      if (titleBtn && titleBtn.textContent?.trim()) {
        return titleBtn.textContent.trim();
      }
      const h1 = document.querySelector("h1");
      if (h1 && h1.textContent?.trim() && !h1.textContent.includes("Claude")) {
        return h1.textContent.trim();
      }
      const title = document.title;
      if (title && !title.startsWith("Claude")) {
        return title.replace(/ - Claude$/, "").trim();
      }
      return "Claude Conversation";
    }
    async extractConversation() {
      const messages = [];
      if (typeof document === "undefined") {
        return { id: generateUniqueId("claude"), provider: this.id, messages };
      }
      let messageEls = Array.from(
        document.querySelectorAll(".font-claude-message, [data-test-render-count], .group\\/turn")
      );
      if (messageEls.length === 0) {
        messageEls = Array.from(document.querySelectorAll(".prose, fieldset + div"));
      }
      for (let i = 0; i < messageEls.length; i++) {
        const el = messageEls[i];
        const isUser = el.querySelector('[data-testid="user-message"]') !== null || el.classList.contains("user-message") || el.getAttribute("data-is-user") === "true" || el.parentElement?.classList.contains("user-message");
        const role = isUser ? "user" : "assistant";
        const content = el.textContent ? el.textContent.trim() : "";
        if (content) {
          messages.push({
            id: generateUniqueId(`claude_msg_${i}`),
            role,
            content,
            timestamp: (/* @__PURE__ */ new Date()).toISOString()
          });
        }
      }
      const title = await this.getConversationTitle();
      return {
        id: generateUniqueId("claude_conv"),
        title: title || "Claude Conversation",
        provider: this.id,
        messages,
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
        url: typeof window !== "undefined" ? window.location.href : void 0,
        isPartial: false
      };
    }
    async injectContext(formattedContext) {
      if (typeof document === "undefined") return false;
      const selectors = [
        ".ProseMirror",
        'fieldset [contenteditable="true"]',
        'div[contenteditable="true"]',
        "p.placeholder",
        "textarea"
      ];
      for (const sel of selectors) {
        const editable = document.querySelector(sel);
        if (editable) {
          return pasteTextIntoElement(editable, formattedContext);
        }
      }
      return false;
    }
  };

  // src/providers/gemini/GeminiProvider.ts
  var GeminiProvider = class extends BaseAIProvider {
    id = "gemini";
    name = "Google Gemini";
    detect() {
      if (typeof window === "undefined") return false;
      const host = window.location.hostname;
      const href = window.location.href;
      if (host.includes("gemini.google.com") || href.includes("gemini.google.com")) {
        return true;
      }
      if (typeof document !== "undefined") {
        if (document.querySelector("user-query") || document.querySelector("model-response") || document.querySelector("rich-textarea")) {
          return true;
        }
      }
      return false;
    }
    async getConversationTitle() {
      if (typeof document === "undefined") return null;
      const titleEl = document.querySelector(".conversation-title, [data-test-id='conversation-title']");
      if (titleEl && titleEl.textContent?.trim()) {
        return titleEl.textContent.trim();
      }
      const title = document.title;
      if (title && !title.startsWith("Gemini")) {
        return title.replace(/ - Gemini$/, "").trim();
      }
      return "Gemini Conversation";
    }
    async extractConversation() {
      const messages = [];
      if (typeof document === "undefined") {
        return { id: generateUniqueId("gemini"), provider: this.id, messages };
      }
      let turnEls = Array.from(
        document.querySelectorAll("user-query, model-response, .user-query-container, .model-response-container, [class*='user-query'], [class*='model-response']")
      );
      if (turnEls.length === 0) {
        turnEls = Array.from(document.querySelectorAll(".message-content, .query-content, .response-content"));
      }
      for (let i = 0; i < turnEls.length; i++) {
        const el = turnEls[i];
        const tag = el.tagName.toLowerCase();
        const isUser = tag === "user-query" || el.classList.contains("user-query-container") || el.className.includes("user-query") || el.className.includes("query");
        const role = isUser ? "user" : "assistant";
        const content = el.textContent ? el.textContent.trim() : "";
        if (content) {
          messages.push({
            id: generateUniqueId(`gemini_msg_${i}`),
            role,
            content,
            timestamp: (/* @__PURE__ */ new Date()).toISOString()
          });
        }
      }
      const title = await this.getConversationTitle();
      return {
        id: generateUniqueId("gemini_conv"),
        title: title || "Gemini Conversation",
        provider: this.id,
        messages,
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
        url: typeof window !== "undefined" ? window.location.href : void 0,
        isPartial: false
      };
    }
    async injectContext(formattedContext) {
      if (typeof document === "undefined") return false;
      const selectors = [
        'rich-textarea div[contenteditable="true"]',
        '.rich-textarea div[contenteditable="true"]',
        'div[contenteditable="true"]',
        "textarea"
      ];
      for (const sel of selectors) {
        const editable = document.querySelector(sel);
        if (editable) {
          return pasteTextIntoElement(editable, formattedContext);
        }
      }
      return false;
    }
  };

  // src/providers/perplexity/PerplexityProvider.ts
  var PerplexityProvider = class extends BaseAIProvider {
    id = "perplexity";
    name = "Perplexity";
    detect() {
      if (typeof window === "undefined") return false;
      const host = window.location.hostname;
      const href = window.location.href;
      if (host.includes("perplexity.ai") || href.includes("perplexity.ai")) {
        return true;
      }
      if (typeof document !== "undefined") {
        if (document.querySelector('[data-testid="query"]') || document.querySelector('[data-testid="answer"]')) {
          return true;
        }
      }
      return false;
    }
    async getConversationTitle() {
      if (typeof document === "undefined") return null;
      const h1 = document.querySelector("h1");
      if (h1 && h1.textContent?.trim()) {
        return h1.textContent.trim();
      }
      const title = document.title;
      if (title && !title.startsWith("Perplexity")) {
        return title.replace(/ - Perplexity$/, "").trim();
      }
      return "Perplexity Conversation";
    }
    async extractConversation() {
      const messages = [];
      if (typeof document === "undefined") {
        return { id: generateUniqueId("pplx"), provider: this.id, messages };
      }
      const turnEls = Array.from(
        document.querySelectorAll('[data-testid="query"], [data-testid="answer"], .prose, .group\\/query')
      );
      for (let i = 0; i < turnEls.length; i++) {
        const el = turnEls[i];
        const testId = el.getAttribute("data-testid");
        const isUser = testId === "query" || el.classList.contains("group/query");
        const role = isUser ? "user" : "assistant";
        const content = el.textContent ? el.textContent.trim() : "";
        if (content) {
          messages.push({
            id: generateUniqueId(`pplx_msg_${i}`),
            role,
            content,
            timestamp: (/* @__PURE__ */ new Date()).toISOString()
          });
        }
      }
      const title = await this.getConversationTitle();
      return {
        id: generateUniqueId("pplx_conv"),
        title: title || "Perplexity Conversation",
        provider: this.id,
        messages,
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
        url: typeof window !== "undefined" ? window.location.href : void 0,
        isPartial: false
      };
    }
    async injectContext(formattedContext) {
      if (typeof document === "undefined") return false;
      const selectors = ['textarea[placeholder*="Ask"]', "textarea", '[contenteditable="true"]'];
      for (const sel of selectors) {
        const el = document.querySelector(sel);
        if (el) {
          return pasteTextIntoElement(el, formattedContext);
        }
      }
      return false;
    }
  };

  // src/providers/grok/GrokProvider.ts
  var GrokProvider = class extends BaseAIProvider {
    id = "grok";
    name = "Grok";
    detect() {
      if (typeof window === "undefined") return false;
      const host = window.location.hostname;
      const href = window.location.href;
      if (host.includes("grok.com") || host.includes("x.ai") || href.includes("grok.com") || href.includes("x.ai")) {
        return true;
      }
      if (typeof document !== "undefined") {
        if (document.querySelector('[data-testid="message-turn"]') || document.querySelector(".user-prompt")) {
          return true;
        }
      }
      return false;
    }
    async getConversationTitle() {
      if (typeof document === "undefined") return null;
      const h1 = document.querySelector("h1");
      if (h1 && h1.textContent?.trim() && h1.textContent.trim() !== "Grok") {
        return h1.textContent.trim();
      }
      const title = document.title;
      if (title && !title.startsWith("Grok")) {
        return title.replace(/ - Grok$/, "").trim();
      }
      return "Grok Conversation";
    }
    async extractConversation() {
      const messages = [];
      if (typeof document === "undefined") {
        return { id: generateUniqueId("grok"), provider: this.id, messages };
      }
      let turnEls = Array.from(
        document.querySelectorAll('[data-testid="message-turn"], .response-turn, .user-prompt, .prose, .message-bubble')
      );
      if (turnEls.length === 0) {
        turnEls = Array.from(document.querySelectorAll('[class*="group/turn"], .items-start'));
      }
      for (let i = 0; i < turnEls.length; i++) {
        const el = turnEls[i];
        const isUser = el.classList.contains("user-prompt") || el.getAttribute("data-is-user") === "true" || el.querySelector('[data-testid="user-avatar"]') !== null || el.innerText?.startsWith("You:");
        const role = isUser ? "user" : "assistant";
        const content = el.textContent ? el.textContent.trim() : "";
        if (content) {
          messages.push({
            id: generateUniqueId(`grok_msg_${i}`),
            role,
            content,
            timestamp: (/* @__PURE__ */ new Date()).toISOString()
          });
        }
      }
      const title = await this.getConversationTitle();
      return {
        id: generateUniqueId("grok_conv"),
        title: title || "Grok Conversation",
        provider: this.id,
        messages,
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
        url: typeof window !== "undefined" ? window.location.href : void 0,
        isPartial: false
      };
    }
    async injectContext(formattedContext) {
      if (typeof document === "undefined") return false;
      const selectors = ['textarea[placeholder*="Ask"]', "textarea", '[contenteditable="true"]'];
      for (const sel of selectors) {
        const el = document.querySelector(sel);
        if (el) {
          return pasteTextIntoElement(el, formattedContext);
        }
      }
      return false;
    }
  };

  // src/providers/copilot/CopilotProvider.ts
  var CopilotProvider = class extends BaseAIProvider {
    id = "copilot";
    name = "Microsoft Copilot";
    detect() {
      if (typeof window === "undefined") return false;
      const host = window.location.hostname;
      const href = window.location.href;
      if (host.includes("copilot.microsoft.com") || host.includes("bing.com") || href.includes("copilot") || href.includes("bing.com/chat")) {
        return true;
      }
      if (typeof document !== "undefined") {
        if (document.querySelector("cib-chat-turn") || document.querySelector(".user-message") || document.querySelector("#searchbox")) {
          return true;
        }
      }
      return false;
    }
    async getConversationTitle() {
      if (typeof document === "undefined") return null;
      const titleEl = document.querySelector(".chat-title, h1, [data-testid='conversation-title']");
      if (titleEl && titleEl.textContent?.trim() && titleEl.textContent.trim() !== "Copilot" && titleEl.textContent.trim() !== "Microsoft Copilot") {
        return titleEl.textContent.trim();
      }
      const title = document.title;
      if (title && !title.startsWith("Copilot")) {
        return title.replace(/ - Copilot$/, "").trim();
      }
      return "Microsoft Copilot Conversation";
    }
    async extractConversation() {
      const messages = [];
      if (typeof document === "undefined") {
        return { id: generateUniqueId("copilot"), provider: this.id, messages };
      }
      let turnEls = Array.from(
        document.querySelectorAll("cib-chat-turn, .user-message, .bot-message, .group-container, [data-author='user']")
      );
      if (turnEls.length === 0) {
        turnEls = Array.from(document.querySelectorAll(".message-content, .ac-container"));
      }
      for (let i = 0; i < turnEls.length; i++) {
        const el = turnEls[i];
        const tag = el.tagName.toLowerCase();
        const isUser = tag.includes("user") || el.classList.contains("user-message") || el.getAttribute("data-author") === "user" || el.querySelector(".user-avatar") !== null;
        const role = isUser ? "user" : "assistant";
        const content = el.textContent ? el.textContent.trim() : "";
        if (content) {
          messages.push({
            id: generateUniqueId(`copilot_msg_${i}`),
            role,
            content,
            timestamp: (/* @__PURE__ */ new Date()).toISOString()
          });
        }
      }
      const title = await this.getConversationTitle();
      return {
        id: generateUniqueId("copilot_conv"),
        title: title || "Microsoft Copilot Conversation",
        provider: this.id,
        messages,
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
        url: typeof window !== "undefined" ? window.location.href : void 0,
        isPartial: false
      };
    }
    async injectContext(formattedContext) {
      if (typeof document === "undefined") return false;
      const selectors = ["#searchbox", 'textarea[aria-label*="Ask"]', "textarea", '[contenteditable="true"]'];
      for (const sel of selectors) {
        const el = document.querySelector(sel);
        if (el) {
          return pasteTextIntoElement(el, formattedContext);
        }
      }
      return false;
    }
  };

  // src/providers/deepseek/DeepSeekProvider.ts
  var DeepSeekProvider = class extends BaseAIProvider {
    id = "deepseek";
    name = "DeepSeek";
    detect() {
      if (typeof window === "undefined") return false;
      const host = window.location.hostname;
      const href = window.location.href;
      if (host.includes("deepseek.com") || href.includes("deepseek.com")) {
        return true;
      }
      if (typeof document !== "undefined") {
        if (document.querySelector(".ds-markdown") || document.querySelector(".chat-message") || document.querySelector(".user-msg")) {
          return true;
        }
      }
      return false;
    }
    async getConversationTitle() {
      if (typeof document === "undefined") return null;
      const titleEl = document.querySelector(".chat-header-title, h1, [data-testid='chat-title']");
      if (titleEl && titleEl.textContent?.trim() && titleEl.textContent.trim() !== "DeepSeek") {
        return titleEl.textContent.trim();
      }
      const title = document.title;
      if (title && !title.startsWith("DeepSeek")) {
        return title.replace(/ - DeepSeek$/, "").trim();
      }
      return "DeepSeek Conversation";
    }
    async extractConversation() {
      const messages = [];
      if (typeof document === "undefined") {
        return { id: generateUniqueId("deepseek"), provider: this.id, messages };
      }
      let turnEls = Array.from(
        document.querySelectorAll(".chat-message, .ds-markdown, .user-msg, .assistant-msg, [data-role]")
      );
      if (turnEls.length === 0) {
        turnEls = Array.from(document.querySelectorAll('[class*="group/message"], .message-turn'));
      }
      for (let i = 0; i < turnEls.length; i++) {
        const el = turnEls[i];
        const roleAttr = el.getAttribute("data-role");
        let isUser = false;
        if (roleAttr === "user") {
          isUser = true;
        } else {
          isUser = el.classList.contains("user-msg") || el.querySelector(".user-avatar") !== null || el.innerText?.startsWith("You:");
        }
        const role = isUser ? "user" : "assistant";
        const content = el.textContent ? el.textContent.trim() : "";
        if (content) {
          messages.push({
            id: generateUniqueId(`ds_msg_${i}`),
            role,
            content,
            timestamp: (/* @__PURE__ */ new Date()).toISOString()
          });
        }
      }
      const title = await this.getConversationTitle();
      return {
        id: generateUniqueId("ds_conv"),
        title: title || "DeepSeek Conversation",
        provider: this.id,
        messages,
        createdAt: (/* @__PURE__ */ new Date()).toISOString(),
        updatedAt: (/* @__PURE__ */ new Date()).toISOString(),
        url: typeof window !== "undefined" ? window.location.href : void 0,
        isPartial: false
      };
    }
    async injectContext(formattedContext) {
      if (typeof document === "undefined") return false;
      const selectors = ['textarea[placeholder*="Send"]', "textarea", '[contenteditable="true"]'];
      for (const sel of selectors) {
        const el = document.querySelector(sel);
        if (el) {
          return pasteTextIntoElement(el, formattedContext);
        }
      }
      return false;
    }
  };

  // src/providers/registry/ProviderRegistry.ts
  var ProviderRegistry = class {
    providers = /* @__PURE__ */ new Map();
    /**
     * Registers an AIProvider adapter instance into the registry.
     */
    register(provider) {
      this.providers.set(provider.id, provider);
    }
    /**
     * Ensures all 7 first-class AI providers are registered.
     */
    ensureRegistered() {
      if (this.providers.size === 0) {
        this.register(new ChatGPTProvider());
        this.register(new ClaudeProvider());
        this.register(new GeminiProvider());
        this.register(new PerplexityProvider());
        this.register(new GrokProvider());
        this.register(new CopilotProvider());
        this.register(new DeepSeekProvider());
      }
    }
    /**
     * Retrieves a registered provider by its ID.
     */
    get(id) {
      this.ensureRegistered();
      return this.providers.get(id);
    }
    /**
     * Returns all registered provider adapter instances.
     */
    getAll() {
      this.ensureRegistered();
      return Array.from(this.providers.values());
    }
    /**
     * Detects the active provider on the current browser page.
     */
    detectCurrent() {
      this.ensureRegistered();
      for (const provider of this.getAll()) {
        if (provider.detect()) {
          return provider;
        }
      }
      return void 0;
    }
    /**
     * Returns all valid target providers excluding the given source provider ID.
     */
    getTargets(sourceId) {
      this.ensureRegistered();
      const targets = this.getAll().filter((p) => p.id !== sourceId);
      return targets.length > 0 ? targets : this.getAll();
    }
    /**
     * Detects provider matching a given URL or hostname string.
     */
    detectFromUrl(url) {
      if (!url) return void 0;
      this.ensureRegistered();
      for (const provider of this.getAll()) {
        if (provider.metadata.hostnamePatterns.some((pattern) => url.includes(pattern))) {
          return provider;
        }
      }
      return void 0;
    }
    /**
     * Checks if a given URL or hostname belongs to any registered provider.
     */
    isSupportedHostname(url) {
      return Boolean(this.detectFromUrl(url));
    }
  };
  var providerRegistry = new ProviderRegistry();

  // src/providers/index.ts
  providerRegistry.register(new ChatGPTProvider());
  providerRegistry.register(new ClaudeProvider());
  providerRegistry.register(new GeminiProvider());
  providerRegistry.register(new PerplexityProvider());
  providerRegistry.register(new GrokProvider());
  providerRegistry.register(new CopilotProvider());
  providerRegistry.register(new DeepSeekProvider());
  function detectActiveProvider() {
    return providerRegistry.detectCurrent() || null;
  }
  function getProviderById(id) {
    return providerRegistry.get(id) || null;
  }

  // src/content/extractor.ts
  var ContentExtractor = class {
    /**
     * Detects active provider and extracts conversation turns from the current tab.
     */
    async extract() {
      const provider = detectActiveProvider();
      if (!provider) {
        throw new Error("No supported AI provider detected on this page.");
      }
      const conversation = await provider.extractConversation();
      const hasScrollTop = document.documentElement.scrollTop > 500 || document.body.scrollTop > 500;
      const isPartial = hasScrollTop && conversation.messages.length < 10;
      return {
        conversation: {
          ...conversation,
          isPartial
        },
        isPartial
      };
    }
  };

  // src/content/injector.ts
  var ContentInjector = class {
    commonSelectors = [
      ".ProseMirror",
      "fieldset [contenteditable='true']",
      "#prompt-textarea",
      "rich-textarea div[contenteditable='true']",
      "textarea[placeholder*='Ask']",
      "textarea[placeholder*='Send']",
      "textarea[placeholder*='Message']",
      "#searchbox",
      "textarea",
      'div[contenteditable="true"]'
    ];
    async inject(formattedContext, targetProviderId) {
      let provider = detectActiveProvider();
      if (!provider && targetProviderId) {
        provider = getProviderById(targetProviderId);
      }
      if (provider) {
        const injected = await provider.injectContext(formattedContext);
        if (injected) {
          return { success: true, method: "autoinject" };
        }
      }
      for (const selector of this.commonSelectors) {
        const element = document.querySelector(selector);
        if (element && (element.offsetWidth > 0 || element.offsetHeight > 0 || element.isConnected)) {
          const pasted = pasteTextIntoElement(element, formattedContext);
          if (pasted) {
            return { success: true, method: "autoinject" };
          }
        }
      }
      return { success: false, method: "clipboard" };
    }
  };

  // src/content/content.ts
  var extractor = new ContentExtractor();
  var injector = new ContentInjector();
  function mountFloatingButton() {
    if (typeof document === "undefined" || document.getElementById("contextbridge-floating-host")) return;
    const host = document.createElement("div");
    host.id = "contextbridge-floating-host";
    const shadowRoot = host.attachShadow({ mode: "closed" });
    const style = document.createElement("style");
    style.textContent = `
    :host { all: initial; }
    button {
      position: fixed;
      right: 18px;
      bottom: 18px;
      z-index: 2147483647;
      display: flex;
      align-items: center;
      gap: 7px;
      border: 0;
      border-radius: 999px;
      padding: 10px 14px;
      background: linear-gradient(135deg, #2563eb, #059669);
      color: #fff;
      box-shadow: 0 6px 20px rgba(15, 23, 42, .28);
      cursor: pointer;
      font: 700 12px -apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif;
      transition: transform .15s ease, box-shadow .15s ease;
    }
    button:hover { transform: translateY(-2px); box-shadow: 0 9px 24px rgba(15, 23, 42, .36); }
    button:active { transform: translateY(0); }
    .mark { font-size: 14px; line-height: 1; }
  `;
    const button = document.createElement("button");
    button.type = "button";
    button.title = "Drag to move \u2022 Click to open ContextBridge";
    button.innerHTML = `<span class="mark">\u2194</span><span>ContextBridge</span>`;
    let isDragging = false;
    let suppressClick = false;
    let startX = 0;
    let startY = 0;
    let startLeft = 0;
    let startTop = 0;
    const applyPosition = (left, top) => {
      const maxLeft = Math.max(8, window.innerWidth - button.offsetWidth - 8);
      const maxTop = Math.max(8, window.innerHeight - button.offsetHeight - 8);
      button.style.left = `${Math.min(Math.max(8, left), maxLeft)}px`;
      button.style.top = `${Math.min(Math.max(8, top), maxTop)}px`;
      button.style.right = "auto";
      button.style.bottom = "auto";
    };
    chrome.storage.local.get("cb_floating_button_position", (result) => {
      const position = result.cb_floating_button_position;
      if (typeof position?.left === "number" && typeof position.top === "number") {
        applyPosition(position.left, position.top);
      }
    });
    button.addEventListener("pointerdown", (event) => {
      isDragging = true;
      suppressClick = false;
      startX = event.clientX;
      startY = event.clientY;
      const rect = button.getBoundingClientRect();
      startLeft = rect.left;
      startTop = rect.top;
      button.setPointerCapture(event.pointerId);
      event.preventDefault();
    });
    button.addEventListener("pointermove", (event) => {
      if (!isDragging) return;
      const deltaX = event.clientX - startX;
      const deltaY = event.clientY - startY;
      if (Math.abs(deltaX) > 4 || Math.abs(deltaY) > 4) suppressClick = true;
      applyPosition(startLeft + deltaX, startTop + deltaY);
    });
    button.addEventListener("pointerup", (event) => {
      if (!isDragging) return;
      isDragging = false;
      button.releasePointerCapture(event.pointerId);
      const rect = button.getBoundingClientRect();
      chrome.storage.local.set({
        cb_floating_button_position: { left: rect.left, top: rect.top }
      });
    });
    button.addEventListener("click", () => {
      if (suppressClick) {
        suppressClick = false;
        return;
      }
      chrome.runtime.sendMessage({ type: "OPEN_EXTENSION_POPUP" }, (response) => {
        if (chrome.runtime.lastError || response?.type === "RESPONSE_ERROR") {
          showInPageNotification("ContextBridge could not open");
        }
      });
    });
    shadowRoot.append(style, button);
    document.documentElement.appendChild(host);
  }
  function showInPageNotification(message) {
    if (typeof document === "undefined") return;
    const existing = document.getElementById("cb-in-page-toast");
    if (existing) existing.remove();
    const toast = document.createElement("div");
    toast.id = "cb-in-page-toast";
    toast.innerText = message;
    toast.setAttribute(
      "style",
      `
      position: fixed;
      bottom: 70px;
      right: 24px;
      background: #10b981;
      color: #ffffff;
      padding: 10px 16px;
      border-radius: 8px;
      font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      font-size: 12px;
      font-weight: 600;
      box-shadow: 0 4px 14px rgba(0, 0, 0, 0.2);
      z-index: 999999;
      transition: all 0.3s ease;
    `
    );
    document.body.appendChild(toast);
    setTimeout(() => {
      toast.style.opacity = "0";
      toast.style.transform = "translateY(10px)";
      setTimeout(() => toast.remove(), 300);
    }, 4e3);
  }
  async function checkAndAutoInjectOnLoad() {
    if (typeof chrome === "undefined" || !chrome.storage || !chrome.storage.local) return;
    chrome.storage.local.get("cb_active_context", async (result) => {
      const activeContext = result["cb_active_context"];
      if (!activeContext || typeof activeContext !== "string" || activeContext.trim().length === 0) {
        return;
      }
      let injected = false;
      const startTime = Date.now();
      const timeoutMs = 25e3;
      const tryInjectNow = async () => {
        if (injected) return true;
        const activeProvider = detectActiveProvider();
        const res = await injector.inject(activeContext, activeProvider?.id);
        if (res.success) {
          injected = true;
          chrome.storage.local.remove("cb_active_context");
          showInPageNotification(
            `Context injected into ${activeProvider?.name || "Composer"}`
          );
          return true;
        }
        return false;
      };
      if (await tryInjectNow()) return;
      const observer = new MutationObserver(async () => {
        if (!injected) {
          if (await tryInjectNow()) {
            observer.disconnect();
          }
        }
      });
      if (document.body) {
        observer.observe(document.body, { childList: true, subtree: true });
      }
      while (Date.now() - startTime < timeoutMs && !injected) {
        if (await tryInjectNow()) {
          observer.disconnect();
          return;
        }
        await new Promise((resolve) => setTimeout(resolve, 500));
      }
      observer.disconnect();
    });
  }
  if (typeof document !== "undefined") {
    mountFloatingButton();
    if (document.readyState === "loading") {
      document.addEventListener("DOMContentLoaded", checkAndAutoInjectOnLoad);
    } else {
      checkAndAutoInjectOnLoad();
    }
  }
  if (typeof chrome !== "undefined" && chrome.runtime && chrome.runtime.onMessage) {
    chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
      (async () => {
        try {
          switch (message.type) {
            case "DETECT_PROVIDER": {
              const active = detectActiveProvider();
              sendResponse({
                type: "RESPONSE_SUCCESS",
                payload: {
                  detected: Boolean(active),
                  providerId: active ? active.id : "unknown",
                  providerName: active ? active.name : "Unknown"
                }
              });
              break;
            }
            case "EXTRACT_CONVERSATION": {
              const result = await extractor.extract();
              sendResponse({
                type: "RESPONSE_SUCCESS",
                payload: result
              });
              break;
            }
            case "INJECT_CONTEXT": {
              const result = await injector.inject(message.payload.formattedContext);
              if (result.success) {
                chrome.storage.local.remove("cb_active_context");
                showInPageNotification("Context Injected into Composer");
              }
              sendResponse({
                type: "RESPONSE_SUCCESS",
                payload: result
              });
              break;
            }
            case "GET_CONVERSATION_TITLE": {
              const active = detectActiveProvider();
              const title = active ? await active.getConversationTitle() : null;
              sendResponse({
                type: "RESPONSE_SUCCESS",
                payload: { title }
              });
              break;
            }
            default:
              sendResponse({
                type: "RESPONSE_ERROR",
                error: "Unknown message type"
              });
          }
        } catch (err) {
          sendResponse({
            type: "RESPONSE_ERROR",
            error: err?.message || "Content script error"
          });
        }
      })();
      return true;
    });
  }
})();
